#![forbid(unsafe_code)]
#![allow(non_snake_case)]

// mod列表
pub mod cli;
pub mod move_ir;
pub mod utils;
pub mod scanner;